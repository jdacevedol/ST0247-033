class Main {
  public static void main(String[] args) {
    Lector pru = new Lector("C://Users//jdacevedol//Documents//Nodos.txt");
    
  }
}