public class Vertice{
    int ini;
    int fin;
    int cost;
    public Vertice(int ini, int fin, int cost){
        this.ini = ini;
        this.fin = fin;
        this.cost = cost; 
    }
    
    
    
}